package com.example.shengsaib10252019;

import java.text.SimpleDateFormat;
import java.util.TimeZone;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.shengsaib10252019.textchanger.TextChanger;
import com.example.shengsaib10252019.toats.DiyToast;

/**
 * @author Administrator
 * @year 2019
 * @Todo TODO ��¼
 * @package_name com.example.shengsaib10252019
 * @project_name 2019ShengSaiB1025D2
 * @file_name LoginActivity.java
 */
public class LoginActivity extends Activity {
	private TextView tv_tips, tv_time;// ʱ�䡢��ʾ
	private EditText et_user, et_port, et_ip, et_pass;
	private String user, port, ip, pass;
	private Button btn_login;// ��¼
	int number = 0;
	SharedPreferences sharedPreferences;// ��ס����

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		// ��
		initView();
		// ��ס����
		if (sharedPreferences != null) {
			if (sharedPreferences.getBoolean("rember", false) == true) {
				et_ip.setText(sharedPreferences.getString("ip", null));
				et_pass.setText(sharedPreferences.getString("pass", null));
				et_port.setText(sharedPreferences.getString("port", null));
				et_user.setText(sharedPreferences.getString("user", null));
			} else {
				et_ip.setText("18.1.10.7");
				et_pass.setText("123456");
				et_port.setText("6006");
				et_user.setText("bizideal");
			}
		}
		// ��¼
		btn_login.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				user = et_user.getText().toString();
				pass = et_pass.getText().toString();
				port = et_port.getText().toString();
				ip = et_ip.getText().toString();
				if (user.isEmpty()) {
					DiyToast.showToast(getApplicationContext(), "�������û���");
				} else if (port.isEmpty()) {
					DiyToast.showToast(getApplicationContext(), "������˿ں�");
				} else if (ip.isEmpty()) {
					DiyToast.showToast(getApplicationContext(), "������IP��ַ");
				} else if (pass.isEmpty()) {
					DiyToast.showToast(getApplicationContext(), "����������");
				} else {
					if (user.equals("bizideal") && pass.equals("123456")) {
						// ��½�ɹ�
						startActivity(new Intent(getApplicationContext(),
								UnLockActivity.class));
						finish();
						// ��ס����
						sharedPreferences.edit().putBoolean("rember", true)
								.putString("user", user)
								.putString("pass", pass).putString("ip", ip)
								.putString("port", port).commit();
					} else {
						new AlertDialog.Builder(LoginActivity.this)
								.setTitle("��¼ʧ��").setMessage("������û����������")
								.setPositiveButton("Ok", null).show();
					}
				}
			}
		});
		// ����ת���ַ�
		et_pass.setTransformationMethod(new TextChanger());
		// �������
		handler.post(timeRunnable);
	}

	private void initView() {
		// TODO Auto-generated method stub
		btn_login = (Button) findViewById(R.id.btn_login);
		tv_time = (TextView) findViewById(R.id.tv_login_time);
		tv_tips = (TextView) findViewById(R.id.tv_login_tips);
		et_ip = (EditText) findViewById(R.id.et_ip);
		et_pass = (EditText) findViewById(R.id.et_pass);
		et_port = (EditText) findViewById(R.id.et_port);
		et_user = (EditText) findViewById(R.id.et_user);
		sharedPreferences = getSharedPreferences("rember", MODE_WORLD_WRITEABLE);
	}

	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what % 2 == 0) {
				tv_tips.setVisibility(View.INVISIBLE);
			} else {
				tv_tips.setVisibility(View.VISIBLE);
			}
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
					"yyyy��MM��dd�� HH:mm:ss");
			simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
			tv_time.setText(simpleDateFormat.format(new java.util.Date()));
			handler.postDelayed(timeRunnable, 500);
		}
	};
	Runnable timeRunnable = new Runnable() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			number++;
			Message msg = handler.obtainMessage();
			msg.what = number;
			handler.sendMessage(msg);
		}
	};
}
