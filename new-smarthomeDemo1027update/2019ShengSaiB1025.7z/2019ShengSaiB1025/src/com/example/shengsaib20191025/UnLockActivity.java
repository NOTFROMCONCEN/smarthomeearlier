package com.example.shengsaib20191025;

import com.example.shengsaib20191025.fragment.BarActivity;
import com.example.shengsaib20191025.toast.DiyToast;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

/**
 * @author Administrator
 * @year 2019
 * @Todo TODO ������������
 * @package_name com.example.shengsaib20191025
 * @project_name 2019ShengSaiB1025
 * @file_name UnLockActivity.java
 */
public class UnLockActivity extends Activity {
	SeekBar skBar;// ������

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_unlock);
		// ��
		skBar = (SeekBar) findViewById(R.id.seekBar1);
		// ���û��������¼�
		skBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {// ֹͣ����
				// TODO Auto-generated method stub
				if (seekBar.getProgress() != 100) {// ���Ȳ�����100
					DiyToast.showToast(getApplicationContext(), "����ɻ�������");// ��ʾ
					skBar.setProgress(0);// ǿ�ƹ���
				} else {
					startActivity(new Intent(UnLockActivity.this,
							BarActivity.class));// ��ת
					finish();
				}
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {// ��ʼ����
				// TODO Auto-generated method stub

			}

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {// ���ȸı�
				// TODO Auto-generated method stub

			}
		});
	}
}
