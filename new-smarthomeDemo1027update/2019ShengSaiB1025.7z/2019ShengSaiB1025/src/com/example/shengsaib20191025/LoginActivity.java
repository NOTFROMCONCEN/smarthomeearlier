package com.example.shengsaib20191025;

import java.text.SimpleDateFormat;
import java.util.TimeZone;

import com.example.shengsaib20191025.textchanger.TextChanger;
import com.example.shengsaib20191025.toast.DiyToast;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * @author Administrator
 * @year 2019
 * @Todo TODO ��¼
 * @package_name com.example.shengsaib20191025
 * @project_name 2019ShengSaiB1025
 * @file_name LoginActivity.java
 */
public class LoginActivity extends Activity {
	private Button btn_login;// ��¼
	private EditText et_user, et_pass, et_port, et_ip;
	private String user, pass, port, ip;
	int number = 0;
	private TextView tv_tips, tv_time;
	SharedPreferences sharedPreferences;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activityy_login);
		initView();
		// ��ס����
		sharedPreferences = getSharedPreferences("rember", MODE_WORLD_WRITEABLE);
		if (sharedPreferences != null) {
			if (sharedPreferences.getBoolean("rember", false) == true) {
				et_ip.setText(sharedPreferences.getString("ip", null));
				et_pass.setText(sharedPreferences.getString("pass", null));
				et_port.setText(sharedPreferences.getString("port", null));
				et_user.setText(sharedPreferences.getString("user", null));
			} else {
				et_ip.setText("12.1.6.2");
				et_pass.setText("123456");
				et_port.setText("6006");
				et_user.setText("bizideal");
			}
		}
		// ���½���
		handler.post(timeRunnable);
		// ��¼
		btn_login.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				user = et_user.getText().toString();
				pass = et_pass.getText().toString();
				port = et_port.getText().toString();
				ip = et_ip.getText().toString();
				if (user.isEmpty()) {
					DiyToast.showToast(getApplicationContext(), "�������û���");
				} else if (port.isEmpty()) {
					DiyToast.showToast(getApplicationContext(), "������˿ں�");
				} else if (ip.isEmpty()) {
					DiyToast.showToast(getApplicationContext(), "������IP��ַ");
				} else if (pass.isEmpty()) {
					DiyToast.showToast(getApplicationContext(), "����������");
				} else {
					if (pass.equals("123456") && user.equals("bizideal")) {
						// ��ס����
						sharedPreferences.edit().putString("user", user)
								.putBoolean("rember", true)
								.putString("pass", pass).putString("ip", ip)
								.putString("port", port).commit();
						startActivity(new Intent(LoginActivity.this,
								UnLockActivity.class));
						finish();
					} else {
						DiyToast.showToast(getApplicationContext(),
								"�û����������������");
						new AlertDialog.Builder(LoginActivity.this)
								.setTitle("��¼ʧ��").setMessage("������û����������")
								.setPositiveButton("Ok", null).show();
					}
				}
			}
		});
		et_pass.setTransformationMethod(new TextChanger());
	}

	// ��
	private void initView() {
		// TODO Auto-generated method stub
		btn_login = (Button) findViewById(R.id.btn_login);
		et_ip = (EditText) findViewById(R.id.et_ip);
		et_pass = (EditText) findViewById(R.id.et_pass);
		et_user = (EditText) findViewById(R.id.et_user);
		et_port = (EditText) findViewById(R.id.et_port);
		tv_time = (TextView) findViewById(R.id.tv_login_time);
		tv_tips = (TextView) findViewById(R.id.tv_login_tips);
	}

	/**
	 * ����ʱ�䡢������˸
	 */
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
					"yyyy��MM��dd�� HH:mm:ss");
			simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
			tv_time.setText(simpleDateFormat.format(new java.util.Date()));
			if (msg.what % 2 == 0) {
				tv_tips.setVisibility(View.VISIBLE);
			} else {
				tv_tips.setVisibility(View.INVISIBLE);
			}
			handler.postDelayed(timeRunnable, 1000);
		}
	};
	Runnable timeRunnable = new Runnable() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			number++;
			Message msg = handler.obtainMessage();
			msg.what = number;
			handler.sendMessage(msg);
		}
	};
}
