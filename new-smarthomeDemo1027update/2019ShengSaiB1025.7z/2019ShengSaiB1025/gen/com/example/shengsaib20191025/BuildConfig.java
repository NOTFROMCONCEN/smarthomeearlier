/** Automatically generated file. DO NOT MODIFY */
package com.example.shengsaib20191025;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}