package com.example.shengsaibd12019.fragment;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.bizideal.smarthome.socket.ConstantUtil;
import com.bizideal.smarthome.socket.ControlUtils;
import com.example.shengsaibd12019.R;
import com.example.shengsaibd12019.toast.DiyToast;

/**
 * @author Administrator
 * @year 2019
 * @Todo TODO ����
 * @package_name com.example.shengsaibd12019.fragment
 * @project_name 2019ShengSaiBD1
 * @file_name LinkActivity.java
 */
public class LinkActivity extends Fragment {
	private Button btn_link_state;
	private Switch sw_lamp;// ���
	private Switch sw_fan;// ����
	private Switch sw_door;// �Ž�
	private Switch sw_warm;// ������
	private Spinner sp_1, sp_2;
	private EditText et_number_get, et_time_get;
	private TextView tv_time, tv_down_time;
	private CountDownTimer timer;
	long num, min, sec;
	boolean link_state = false;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.activity_link, container, false);
		tv_time = (TextView) view.findViewById(R.id.tv_link_time);
		handler.post(timeRunnable);
		initView(view);
		/**
		 * �豸����
		 */
		sw_door.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				if (isChecked) {
					if (link_state) {
						ControlUtils.control(ConstantUtil.RFID_Open_Door,
								ConstantUtil.CHANNEL_1, ConstantUtil.OPEN);
					} else {
						DiyToast.showToast(getActivity(), "����δ����");
						sw_door.setChecked(false);
					}
				} else {

				}
			}
		});
		sw_fan.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				if (isChecked) {
					if (link_state) {
						ControlUtils.control(ConstantUtil.Fan,
								ConstantUtil.CHANNEL_ALL, ConstantUtil.OPEN);
					} else {
						DiyToast.showToast(getActivity(), "����δ����");
						sw_fan.setChecked(false);
					}
				} else {
					ControlUtils.control(ConstantUtil.Fan,
							ConstantUtil.CHANNEL_ALL, ConstantUtil.CLOSE);
				}
			}
		});
		sw_lamp.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				if (isChecked) {
					if (link_state) {
						ControlUtils.control(ConstantUtil.Lamp,
								ConstantUtil.CHANNEL_ALL, ConstantUtil.OPEN);
					} else {
						DiyToast.showToast(getActivity(), "����δ����");
						sw_lamp.setChecked(false);
					}
				} else {
					ControlUtils.control(ConstantUtil.Lamp,
							ConstantUtil.CHANNEL_ALL, ConstantUtil.CLOSE);
				}
			}
		});
		sw_warm.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				if (isChecked) {
					if (link_state) {
						ControlUtils.control(ConstantUtil.WarningLight,
								ConstantUtil.CHANNEL_ALL, ConstantUtil.OPEN);
					} else {
						DiyToast.showToast(getActivity(), "����δ����");
						sw_warm.setChecked(false);
					}
				} else {
					ControlUtils.control(ConstantUtil.WarningLight,
							ConstantUtil.CHANNEL_ALL, ConstantUtil.CLOSE);
				}
			}
		});
		// ����״̬
		btn_link_state.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (et_number_get.getText().toString().isEmpty()) {
					DiyToast.showToast(getActivity(), "��������ֵ");
				} else if (et_time_get.getText().toString().isEmpty()) {
					DiyToast.showToast(getActivity(), "������ʱ��");
				} else {
					if (btn_link_state.getText().toString().equals("��������")) {
						String spinner_1 = sp_1.getSelectedItem().toString();
						String spinner_2 = sp_2.getSelectedItem().toString();
						int number_get = Integer.valueOf(et_number_get
								.getText().toString());
						if (spinner_1.equals("�¶�")) {
							if (spinner_2.equals(">")) {
								if (BaseActivity.temp > number_get) {
									link_state = true;
									btn_link_state.setText("�ر�����");
								} else {
									DiyToast.showToast(getActivity(), "����������");
									link_state = false;
									set_sw_state();
								}
							}
							if (spinner_2.equals("<=")) {
								if (BaseActivity.temp <= number_get) {
									link_state = true;
									btn_link_state.setText("�ر�����");
								} else {
									DiyToast.showToast(getActivity(), "����������");
									link_state = false;
									set_sw_state();
								}
							}
						}
						if (spinner_1.equals("����")) {
							if (spinner_2.equals(">")) {
								if (BaseActivity.ill > number_get) {
									link_state = true;
									btn_link_state.setText("�ر�����");
								} else {
									DiyToast.showToast(getActivity(), "����������");
									link_state = false;
									set_sw_state();
								}
							}
							if (spinner_2.equals("<=")) {
								if (BaseActivity.ill <= number_get) {
									link_state = true;
									btn_link_state.setText("�ر�����");
								} else {
									DiyToast.showToast(getActivity(), "����������");
									link_state = false;
									set_sw_state();
								}
							}

						}
						if (spinner_1.equals("ʪ��")) {
							if (spinner_2.equals(">")) {
								if (BaseActivity.hum > number_get) {
									link_state = true;
									btn_link_state.setText("�ر�����");
								} else {
									DiyToast.showToast(getActivity(), "����������");
									link_state = false;
									set_sw_state();
								}
							}
							if (spinner_2.equals("<=")) {
								if (BaseActivity.hum <= number_get) {
									link_state = true;
									btn_link_state.setText("�ر�����");
								} else {
									DiyToast.showToast(getActivity(), "����������");
									link_state = false;
									set_sw_state();
								}
							}

						}
					} else if (btn_link_state.getText().toString()
							.equals("�ر�����")) {
						if (timer != null) {
							timer.cancel();
						}
						set_sw_state();
						link_state = false;
						btn_link_state.setText("��������");
						tv_down_time.setText("����ģʽ����X��X��");
					}
					if (link_state) {
						num = Integer.valueOf(et_time_get.getText().toString()) * 1000 * 60;
						timer = new CountDownTimer(num, 1000) {

							@Override
							public void onTick(long millisUntilFinished) {
								// TODO Auto-generated method stub
								min = millisUntilFinished / 1000 / 60;
								sec = millisUntilFinished / 1000 % 60;
								tv_down_time.setText("����ģʽ����" + min + "��" + sec
										+ "��");
							}

							@Override
							public void onFinish() {
								// TODO Auto-generated method stub
								set_sw_state();
								if (timer != null) {
									timer.cancel();
								}
								tv_down_time.setText("����ģʽ����X��X��");
								link_state = false;
								btn_link_state.setText("��������");
							}
						}.start();
					}
				}
			}
		});
		return view;
	}

	private void initView(View view) {
		// TODO Auto-generated method stub
		btn_link_state = (Button) view.findViewById(R.id.btn_link_state);
		sw_door = (Switch) view.findViewById(R.id.sw_door);
		sw_fan = (Switch) view.findViewById(R.id.sw_fan);
		sw_lamp = (Switch) view.findViewById(R.id.sw_lamp);
		sw_warm = (Switch) view.findViewById(R.id.sw_warm);
		et_number_get = (EditText) view.findViewById(R.id.et_number_get);
		et_time_get = (EditText) view.findViewById(R.id.et_time_get);
		tv_down_time = (TextView) view.findViewById(R.id.tv_down_time);
		sp_1 = (Spinner) view.findViewById(R.id.spinner1);
		sp_2 = (Spinner) view.findViewById(R.id.spinner2);
	}

	/*
	 * ʱ��
	 */
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			tv_time.setText(BarActivity.time);
			handler.postDelayed(timeRunnable, 1000);
		}
	};
	Runnable timeRunnable = new Runnable() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			Message msg = handler.obtainMessage();
			handler.sendMessage(msg);
		}
	};

	/**
	 * ���ùر�
	 */
	private void set_sw_state() {
		// TODO Auto-generated method stub
		if (sw_door.isChecked()) {
			sw_door.setChecked(false);
			ControlUtils.control(ConstantUtil.RFID_Open_Door,
					ConstantUtil.CHANNEL_1, ConstantUtil.CLOSE);
		}
		if (sw_fan.isChecked()) {
			sw_fan.setChecked(false);
			ControlUtils.control(ConstantUtil.Fan, ConstantUtil.CHANNEL_ALL,
					ConstantUtil.CLOSE);
		}
		if (sw_lamp.isChecked()) {
			sw_lamp.setChecked(false);
			ControlUtils.control(ConstantUtil.Lamp, ConstantUtil.CHANNEL_ALL,
					ConstantUtil.CLOSE);
		}
		if (sw_warm.isChecked()) {
			sw_warm.setChecked(false);
			ControlUtils.control(ConstantUtil.WarningLight,
					ConstantUtil.CHANNEL_ALL, ConstantUtil.CLOSE);
		}

	}
}
