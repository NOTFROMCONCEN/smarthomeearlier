package com.example.shengsaibd12019.fragment;

import com.example.shengsaibd12019.R;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * @author Administrator
 * @year 2019
 * @Todo TODO ��ͼ
 * @package_name com.example.shengsaibd12019.fragment
 * @project_name 2019ShengSaiBD1
 * @file_name DrawActivity.java
 */
public class DrawActivity extends Fragment {
	TextView tv_time;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.activity_dra, container, false);
		tv_time = (TextView) view.findViewById(R.id.tv_draw_time);
		handler.post(timeRunnable);
		return view;
	}

	/**
	 * ����
	 */
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			tv_time.setText(BarActivity.time);
			handler.postDelayed(timeRunnable, 500);
		}
	};
	Runnable timeRunnable = new Runnable() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			Message msg = handler.obtainMessage();
			handler.sendMessage(msg);
		}
	};

}
