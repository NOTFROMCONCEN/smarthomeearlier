package com.example.shengsaibd12019;

import com.example.shengsaibd12019.fragment.BarActivity;
import com.example.shengsaibd12019.toast.DiyToast;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

/**
 * @author Administrator
 * @year 2019
 * @Todo TODO ��������
 * @package_name com.example.shengsaibd12019
 * @project_name 2019ShengSaiBD1
 * @file_name UnLockActivity.java
 */
public class UnLockActivity extends Activity {
	SeekBar sk_1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_unlock);
		sk_1 = (SeekBar) findViewById(R.id.seekBar1);
		setTitle("���ܼҾ�");
		/**
		 * ������������ʵ��
		 */
		sk_1.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				if (seekBar.getProgress() != 100) {
					sk_1.setProgress(0);
					DiyToast.showToast(getApplicationContext(), "����ɻ�������");
				} else {
					DiyToast.showToast(getApplicationContext(), "�������");
					startActivity(new Intent(UnLockActivity.this,
							BarActivity.class));
					finish();
				}
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				// TODO Auto-generated method stub

			}
		});
	}
}
