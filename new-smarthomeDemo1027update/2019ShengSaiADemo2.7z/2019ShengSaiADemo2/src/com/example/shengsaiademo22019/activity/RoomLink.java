package com.example.shengsaiademo22019.activity;

import java.io.Console;

import android.app.Activity;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.bizideal.smarthome.socket.ConstantUtil;
import com.bizideal.smarthome.socket.ControlUtils;
import com.example.shengsaiademo22019.R;
import com.example.shengsaiademo22019.fragment.LinkFragment;
import com.example.shengsaiademo22019.toast.DiyToast;

public class RoomLink extends Activity {
	private TextView tv_link_number;
	private Switch sw_link_state;
	private Spinner sp_1;
	private Spinner sp_2;
	private Spinner sp_3;
	private Spinner sp_4;
	private EditText et_number;
	private boolean link_state;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_link);
		tv_link_number = (TextView) findViewById(R.id.tv_link_room_number);
		tv_link_number.setText("����ţ�" + LinkFragment.room_number);
		initView();
		sw_link_state.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				if (isChecked) {
					if (et_number.getText().toString().isEmpty()) {
						DiyToast.showToast(getApplicationContext(), "��������ֵ");
						link_state = false;
						sw_link_state.setChecked(false);
					} else {
						link_state = true;
						final String spinner_1 = sp_1.getSelectedItem()
								.toString();
						final String spinner_2 = sp_2.getSelectedItem()
								.toString();
						final String spinner_3 = sp_3.getSelectedItem()
								.toString();
						final String spinner_4 = sp_4.getSelectedItem()
								.toString();
						final int number_get = Integer.valueOf(et_number
								.getText().toString());
						new Thread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								while (link_state
										&& !et_number.getText().toString()
												.isEmpty()) {
									try {
										Thread.sleep(1000);
									} catch (Exception e) {
										// TODO: handle exception
										e.printStackTrace();
									}
									if (spinner_1.equals("�ն�")) {
										if (spinner_2.equals(">")) {
											if (LinkFragment.ill > number_get) {
												if (spinner_3.equals("��")) {
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_1,
																		ConstantUtil.OPEN);
													}

												}
												if (spinner_3.equals("��")) {

													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_3,
																		ConstantUtil.OPEN);
													}

												}
											}
										}

										if (spinner_2.equals("<")) {

											if (LinkFragment.ill < number_get) {
												if (spinner_3.equals("��")) {
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_1,
																		ConstantUtil.OPEN);
													}

												}
												if (spinner_3.equals("��")) {

													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_3,
																		ConstantUtil.OPEN);
													}

												}
											}

										}
									}
									if (spinner_1.equals("ʪ��")) {

										if (spinner_2.equals(">")) {
											if (LinkFragment.hum > number_get) {
												if (spinner_3.equals("��")) {
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_1,
																		ConstantUtil.OPEN);
													}

												}
												if (spinner_3.equals("��")) {

													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_3,
																		ConstantUtil.OPEN);
													}

												}
											}
										}

										if (spinner_2.equals("<")) {

											if (LinkFragment.hum < number_get) {
												if (spinner_3.equals("��")) {
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_1,
																		ConstantUtil.OPEN);
													}

												}
												if (spinner_3.equals("��")) {

													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_3,
																		ConstantUtil.OPEN);
													}

												}
											}

										}

									}
									if (spinner_1.equals("�¶�")) {

										if (spinner_2.equals(">")) {
											if (LinkFragment.temp > number_get) {
												if (spinner_3.equals("��")) {
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_1,
																		ConstantUtil.OPEN);
													}

												}
												if (spinner_3.equals("��")) {

													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_3,
																		ConstantUtil.OPEN);
													}

												}
											}
										}

										if (spinner_2.equals("<")) {

											if (LinkFragment.temp < number_get) {
												if (spinner_3.equals("��")) {
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.OPEN);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_1,
																		ConstantUtil.OPEN);
													}

												}
												if (spinner_3.equals("��")) {

													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Fan,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("���")) {
														ControlUtils
																.control(
																		ConstantUtil.Lamp,
																		ConstantUtil.CHANNEL_ALL,
																		ConstantUtil.CLOSE);
													}
													if (spinner_4.equals("����")) {
														ControlUtils
																.control(
																		ConstantUtil.Curtain,
																		ConstantUtil.CHANNEL_3,
																		ConstantUtil.OPEN);
													}

												}
											}

										}

									}
								}
							}
						}).start();
					}
				} else {
					link_state = false;
				}
			}
		});
	}

	private void initView() {
		// TODO Auto-generated method stub
		sw_link_state = (Switch) findViewById(R.id.sw_link_state);
		sp_1 = (Spinner) findViewById(R.id.spinner1);
		sp_2 = (Spinner) findViewById(R.id.spinner2);
		sp_3 = (Spinner) findViewById(R.id.spinner3);
		sp_4 = (Spinner) findViewById(R.id.spinner4);
		et_number = (EditText) findViewById(R.id.et_number_get);
	}
}
