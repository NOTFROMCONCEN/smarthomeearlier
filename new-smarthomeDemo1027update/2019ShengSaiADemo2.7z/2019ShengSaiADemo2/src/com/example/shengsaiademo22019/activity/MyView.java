package com.example.shengsaiademo22019.activity;

import java.util.ArrayList;
import java.util.List;

import com.example.shengsaiademo22019.fragment.BaseFragment;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;

public class MyView extends View {
	private int Xpoint = 40;
	private int Ypoint = 300;
	private int Xline = 720;
	private int Yline = 270;
	private int Xheight = 90;
	private int Yheight = 100;
	List<Float> data = new ArrayList<Float>();
	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == 0x1234) {
				MyView.this.invalidate();
			}
		}
	};

	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				while (true) {
					try {
						Thread.sleep(1000);
					} catch (Exception e) {
						// TODO: handle exception
					}
					if (data.size() > 6) {
						data.remove(0);
					}
					data.add(BaseFragment.temp);
					handler.sendEmptyMessage(0x1234);
				}
			}
		}).start();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		paint.setColor(Color.BLACK);
		paint.setStyle(Style.STROKE);
		paint.setStrokeWidth(5);
		canvas.drawLine(Xpoint + 40, Ypoint, Xpoint + Xline, Ypoint, paint);
		canvas.drawLine(Xpoint + 60, Ypoint + 20, Xpoint + 60, Ypoint - Yline,
				paint);
		if (data.size() > 1) {
			for (int i = 1; i < data.size(); i++) {
				if (data.get(i - 1) >= 15 & data.get(i) >= 15) {
					Paint paint2 = new Paint();
					paint2.setAntiAlias(true);
					paint2.setStrokeWidth(5);
					paint2.setColor(Color.RED);
					canvas.drawLine(Xpoint + i * Xheight,
							Ypoint - data.get(i - 1) * Yheight / 20, Xpoint
									+ (i + 1) * Xheight, Ypoint - data.get(i)
									* Yheight / 20, paint2);
				} else if (data.get(i - 1) < 15 && data.get(i) < 15) {
					Paint paint2 = new Paint();
					paint2.setAntiAlias(true);
					paint2.setStrokeWidth(5);
					paint2.setColor(Color.BLACK);
					canvas.drawLine(Xpoint + i * Xheight,
							Ypoint - data.get(i - 1) * Yheight / 20, Xpoint
									+ (i + 1) * Xheight, Ypoint - data.get(i)
									* Yheight / 20, paint2);
				} else if (data.get(i - 1) < 15 && data.get(i) >= 15) {
					Paint paint2 = new Paint();
					paint2.setAntiAlias(true);
					paint2.setStrokeWidth(5);
					paint2.setColor(Color.BLACK);
					canvas.drawLine(Xpoint + i * Xheight,
							Ypoint - data.get(i - 1) * Yheight / 20, Xpoint
									+ (i + 1) * Xheight, Ypoint - data.get(i)
									* Yheight / 20, paint2);
				} else if (data.get(i - 1) >= 15 && data.get(i) < 15) {
					Paint paint2 = new Paint();
					paint2.setAntiAlias(true);
					paint2.setStrokeWidth(5);
					paint2.setColor(Color.BLACK);
					canvas.drawLine(Xpoint + i * Xheight,
							Ypoint - data.get(i - 1) * Yheight / 20, Xpoint
									+ (i + 1) * Xheight, Ypoint - data.get(i)
									* Yheight / 20, paint2);
				}
			}
		}
	}
}
