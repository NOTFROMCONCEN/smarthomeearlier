package com.example.shengsaiademo22019.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.shengsaiademo22019.R;
import com.example.shengsaiademo22019.fragment.DrawFragment;

public class RoomDraw extends Activity {
	private TextView tv_number;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_draw);
		tv_number = (TextView) findViewById(R.id.tv_draw_room);
		tv_number.setText("���ţ�" + DrawFragment.room_number);
	}
}
