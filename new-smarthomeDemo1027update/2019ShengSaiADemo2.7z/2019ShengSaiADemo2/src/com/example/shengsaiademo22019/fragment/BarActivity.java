package com.example.shengsaiademo22019.fragment;

import java.util.ArrayList;
import java.util.List;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.bizideal.smarthome.socket.ConstantUtil;
import com.bizideal.smarthome.socket.ControlUtils;
import com.bizideal.smarthome.socket.LoginCallback;
import com.bizideal.smarthome.socket.SocketClient;
import com.example.shengsaiademo22019.R;
import com.example.shengsaiademo22019.toast.DiyToast;

public class BarActivity extends FragmentActivity {

	/**
	 * The {@link android.support.v4.view.PagerAdapter} that will provide
	 * fragments for each of the sections. We use a
	 * {@link android.support.v4.app.FragmentPagerAdapter} derivative, which
	 * will keep every loaded fragment in memory. If this becomes too memory
	 * intensive, it may be best to switch to a
	 * {@link android.support.v4.app.FragmentStatePagerAdapter}.
	 */
	SectionsPagerAdapter mSectionsPagerAdapter;
	private Button btn_base;
	private Button btn_control;
	private Button btn_link;
	private Button btn_draw;
	private View view_1;
	private View view_2;
	private View view_3;
	private View view_4;
	Button btn_logo_weidasao;
	Button btn_logo_keruzhu;
	Button btn_logo_yiruzhu;

	/**
	 * The {@link ViewPager} that will host the section contents.
	 */
	ViewPager mViewPager;
	List<Fragment> faFragments = new ArrayList<Fragment>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bar);
		faFragments.add(new BaseFragment());
		faFragments.add(new ControlFragment());
		faFragments.add(new LinkFragment());
		faFragments.add(new DrawFragment());
		view_1 = (View) findViewById(R.id.view_1);
		view_2 = (View) findViewById(R.id.view_2);
		view_3 = (View) findViewById(R.id.view_3);
		view_4 = (View) findViewById(R.id.view_4);

		ControlUtils.setUser("bizideal", "123456", "18.1.10.7");
		SocketClient.getInstance().creatConnect();
		SocketClient.getInstance().login(new LoginCallback() {

			@Override
			public void onEvent(final String arg0) {
				// TODO Auto-generated method stub
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						if (arg0.equals(ConstantUtil.SUCCESS)) {
							DiyToast.showToast(getApplicationContext(), "�����ɹ�");
						} else {
							DiyToast.showToast(getApplicationContext(), "����ʧ��");
						}
					}
				});

			}
		});

		btn_base = (Button) findViewById(R.id.btn_base);
		btn_control = (Button) findViewById(R.id.btn_control);
		btn_link = (Button) findViewById(R.id.btn_link);
		btn_draw = (Button) findViewById(R.id.btn_draw);
		btn_logo_keruzhu = (Button) findViewById(R.id.btn_show_keruzhu);
		btn_logo_weidasao = (Button) findViewById(R.id.btn_show_weidasao);
		btn_logo_yiruzhu = (Button) findViewById(R.id.btn_show_yiruzhu);
		btn_logo_weidasao.setBackgroundColor(Color.GRAY);
		btn_logo_keruzhu.setBackgroundColor(Color.GREEN);
		btn_logo_yiruzhu.setBackgroundColor(Color.RED);
		btn_base.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mViewPager.setCurrentItem(0);
				view_1.setBackgroundColor(Color.CYAN);
				view_2.setBackgroundColor(Color.WHITE);
				view_3.setBackgroundColor(Color.WHITE);
				view_4.setBackgroundColor(Color.WHITE);
			}
		});
		btn_control.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mViewPager.setCurrentItem(1);
				view_1.setBackgroundColor(Color.WHITE);
				view_2.setBackgroundColor(Color.CYAN);
				view_3.setBackgroundColor(Color.WHITE);
				view_4.setBackgroundColor(Color.WHITE);
			}
		});
		btn_draw.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mViewPager.setCurrentItem(3);
				view_1.setBackgroundColor(Color.WHITE);
				view_2.setBackgroundColor(Color.WHITE);
				view_3.setBackgroundColor(Color.WHITE);
				view_4.setBackgroundColor(Color.CYAN);
			}
		});
		btn_link.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mViewPager.setCurrentItem(2);
				view_1.setBackgroundColor(Color.WHITE);
				view_2.setBackgroundColor(Color.WHITE);
				view_3.setBackgroundColor(Color.CYAN);
				view_4.setBackgroundColor(Color.WHITE);
			}
		});
		view_1.setBackgroundColor(Color.CYAN);
		view_2.setBackgroundColor(Color.WHITE);
		view_3.setBackgroundColor(Color.WHITE);
		view_4.setBackgroundColor(Color.WHITE);

		// Create the adapter that will return a fragment for each of the three
		// primary sections of the app.
		mSectionsPagerAdapter = new SectionsPagerAdapter(
				getSupportFragmentManager(), faFragments);

		// Set up the ViewPager with the sections adapter.
		mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(mSectionsPagerAdapter);
		mViewPager.setOffscreenPageLimit(0);
		mViewPager
				.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
					@Override
					public void onPageSelected(int position) {
						if (position == 0) {
							view_1.setBackgroundColor(Color.CYAN);
							view_2.setBackgroundColor(Color.WHITE);
							view_3.setBackgroundColor(Color.WHITE);
							view_4.setBackgroundColor(Color.WHITE);
						}
						if (position == 1) {
							view_1.setBackgroundColor(Color.WHITE);
							view_2.setBackgroundColor(Color.CYAN);
							view_3.setBackgroundColor(Color.WHITE);
							view_4.setBackgroundColor(Color.WHITE);
						}
						if (position == 2) {
							view_1.setBackgroundColor(Color.WHITE);
							view_2.setBackgroundColor(Color.WHITE);
							view_3.setBackgroundColor(Color.CYAN);
							view_4.setBackgroundColor(Color.WHITE);
						}
						if (position == 3) {
							view_1.setBackgroundColor(Color.WHITE);
							view_2.setBackgroundColor(Color.WHITE);
							view_3.setBackgroundColor(Color.WHITE);
							view_4.setBackgroundColor(Color.CYAN);
						}
					}
				});
	}

	/**
	 * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
	 * one of the sections/tabs/pages.
	 */
	public class SectionsPagerAdapter extends FragmentPagerAdapter {

		List<Fragment> fragments = new ArrayList<Fragment>();

		public SectionsPagerAdapter(FragmentManager fm, List<Fragment> fragments) {
			super(fm);
			this.fragments = fragments;
		}

		@Override
		public int getCount() {
			// Show 3 total pages.
			return fragments.size();
		}

		@Override
		public Fragment getItem(int arg0) {
			// TODO Auto-generated method stub
			return fragments.get(arg0);
		}

	}
}
