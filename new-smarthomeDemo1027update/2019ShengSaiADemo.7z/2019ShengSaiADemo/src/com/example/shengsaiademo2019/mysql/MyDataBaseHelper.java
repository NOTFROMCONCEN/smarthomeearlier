package com.example.shengsaiademo2019.mysql;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDataBaseHelper extends SQLiteOpenHelper {

	public MyDataBaseHelper(Context context, String name,
			CursorFactory factory, int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		/*
		 * 810X
		 */
		db.execSQL("create table room8101(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8102(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8103(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8104(_id integer primary key autoincrement,roomstate text)");
		/*
		 * 820X
		 */
		db.execSQL("create table room8201(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8202(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8203(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8204(_id integer primary key autoincrement,roomstate text)");
		/*
		 * 830X
		 */
		db.execSQL("create table room8301(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8302(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8303(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8304(_id integer primary key autoincrement,roomstate text)");
		/*
		 * 840X
		 */
		db.execSQL("create table room8401(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8402(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8403(_id integer primary key autoincrement,roomstate text)");
		db.execSQL("create table room8404(_id integer primary key autoincrement,roomstate text)");
		for (int i = 1; i < 5; i++) {
			for (int j = 1; j < 5; j++) {
				db.execSQL("insert into room8" + String.valueOf(i) + "0"
						+ String.valueOf(j) + "(roomstate)values(?)",
						new String[] { "1" });
			}
		}
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub

	}

}
