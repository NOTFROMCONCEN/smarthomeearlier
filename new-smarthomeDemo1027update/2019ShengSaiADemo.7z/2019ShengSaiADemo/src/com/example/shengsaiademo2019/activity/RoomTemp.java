package com.example.shengsaiademo2019.activity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;

import com.example.shengsaiademo2019.R;
import com.example.shengsaiademo2019.fragment.BaseActivity;
import com.example.shengsaiademo2019.fragment.DrawActivity;

/**
 * @author Administrator
 * @year 2019
 * @Todo TODO
 * @package_name com.example.shengsaiademo2019.activity
 * @project_name 2019ShengSaiADemo
 * @file_name RoomTemp.java
 */
public class RoomTemp extends Activity {
	private TextView tv_temp_roomnumber;
	public static boolean draw_state = true;
	public static float getdata;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_room_tempstate);
		tv_temp_roomnumber = (TextView) findViewById(R.id.tv_temp_roomnumber);
		tv_temp_roomnumber.setText("����ţ�" + DrawActivity.Room_numebr);
		// �������
		handler.post(timeRunnable);
	}

	/*
	 * @��������handler
	 * 
	 * @�� �ܣ��������
	 * 
	 * @ʱ �䣺����9:45:29
	 */
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			getdata = BaseActivity.temp;
			Log.e("�¶�", String.valueOf(getdata));
			handler.postDelayed(timeRunnable, 1000);
		}
	};
	Runnable timeRunnable = new Runnable() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			Message msg = handler.obtainMessage();
			handler.sendMessage(msg);
		}
	};
}
