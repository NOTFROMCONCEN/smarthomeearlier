package com.example.shengsaiademo2019.fragment;

import java.text.DecimalFormat;
import java.util.Random;

import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bizideal.smarthome.socket.ConstantUtil;
import com.bizideal.smarthome.socket.DataCallback;
import com.bizideal.smarthome.socket.DeviceBean;
import com.bizideal.smarthome.socket.SocketClient;
import com.example.shengsaiademo2019.R;
import com.example.shengsaiademo2019.mysql.MyDataBaseHelper;

public class BaseActivity extends Fragment implements OnClickListener {
	MyDataBaseHelper dbHelper;
	Random random = new Random();
	SQLiteDatabase db;
	private LinearLayout line_8101;
	private LinearLayout line_8102;
	private LinearLayout line_8103;
	private LinearLayout line_8104;
	private LinearLayout line_8201;
	private LinearLayout line_8202;
	private LinearLayout line_8203;
	private LinearLayout line_8204;
	private LinearLayout line_8301;
	private LinearLayout line_8302;
	private LinearLayout line_8303;
	private LinearLayout line_8304;
	private LinearLayout line_8401;
	private LinearLayout line_8402;
	private LinearLayout line_8403;
	private LinearLayout line_8404;
	public static String Room_numebr = "";
	public static float temp, hum, ill, press, pm, co, smo, gas, per;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.activity_base_index, container,
				false);
		initView(view);

		/**
		 * ���ݲɼ�
		 */
		SocketClient.getInstance().getData(new DataCallback<DeviceBean>() {

			@Override
			public void onResult(final DeviceBean getdata) {
				// TODO Auto-generated method stub
				getActivity().runOnUiThread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						if (!TextUtils.isEmpty(getdata.getAirPressure())) {
							press = Float.valueOf(getdata.getAirPressure());
						}
						if (!TextUtils.isEmpty(getdata.getCo2())) {
							co = Float.valueOf(getdata.getCo2());
						}
						if (!TextUtils.isEmpty(getdata.getGas())) {
							gas = Float.valueOf(getdata.getGas());
						}
						if (!TextUtils.isEmpty(getdata.getHumidity())) {
							hum = Float.valueOf(getdata.getHumidity());
						}
						if (!TextUtils.isEmpty(getdata.getIllumination())) {
							ill = Float.valueOf(getdata.getIllumination());
						}
						if (!TextUtils.isEmpty(getdata.getPM25())) {
							pm = Float.valueOf(getdata.getPM25());
						}
						if (!TextUtils.isEmpty(getdata.getSmoke())) {
							smo = Float.valueOf(getdata.getSmoke());
						}
						if (!TextUtils.isEmpty(getdata.getTemperature())) {
							temp = Float.valueOf(getdata.getTemperature());
						}
						if (!TextUtils.isEmpty(getdata.getStateHumanInfrared())) {
							if (getdata.getStateHumanInfrared().equals(
									ConstantUtil.CLOSE)) {
								per = 0;
							} else {
								per = 1;
							}
						}
					}
				});
			}
		});
		handler.post(timeRunnable);
		return view;
	}

	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			temp = Float.valueOf(random.nextInt(40) % (40 - 20 + 1));// �¶�
			hum = Float.valueOf(random.nextInt(40) % (120 - 10 + 1));// ʪ��
			gas = Float.valueOf(random.nextInt(40) % (40 - 10 + 1));// ȼ��
			smo = Float.valueOf(random.nextInt(40) % (40 - 10 + 1));// ����
			ill = Float.valueOf(random.nextInt(9999) % (9999 - 500 + 1));// ����
			co = Float.valueOf(random.nextInt(40) % (100 - 10 + 1));// Co2
			pm = Float.valueOf(random.nextInt(40) % (100 - 40 + 1));// pm2.5
			press = Float.valueOf(random.nextInt(1800) % (1800 - 10 + 1));// ��ѹ
			if (Float.valueOf(random.nextInt(10) % (10 - 1 + 1)) > 5) {
				per = 1;
			} else {
				per = 0;
			}
			handler.postDelayed(timeRunnable, 2000);
		}
	};
	Runnable timeRunnable = new Runnable() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			Message msg = handler.obtainMessage();
			handler.sendMessage(msg);
		}
	};

	private void initView(View view) {
		// TODO Auto-generated method stub
		line_8101 = (LinearLayout) view.findViewById(R.id.line_8101);
		line_8102 = (LinearLayout) view.findViewById(R.id.line_8102);
		line_8103 = (LinearLayout) view.findViewById(R.id.line_8103);
		line_8104 = (LinearLayout) view.findViewById(R.id.line_8104);

		line_8101.setOnClickListener(this);
		line_8102.setOnClickListener(this);
		line_8103.setOnClickListener(this);
		line_8104.setOnClickListener(this);

		line_8201 = (LinearLayout) view.findViewById(R.id.line_8201);
		line_8202 = (LinearLayout) view.findViewById(R.id.line_8202);
		line_8203 = (LinearLayout) view.findViewById(R.id.line_8203);
		line_8204 = (LinearLayout) view.findViewById(R.id.line_8204);

		line_8201.setOnClickListener(this);
		line_8202.setOnClickListener(this);
		line_8203.setOnClickListener(this);
		line_8204.setOnClickListener(this);

		line_8301 = (LinearLayout) view.findViewById(R.id.line_8301);
		line_8302 = (LinearLayout) view.findViewById(R.id.line_8302);
		line_8303 = (LinearLayout) view.findViewById(R.id.line_8303);
		line_8304 = (LinearLayout) view.findViewById(R.id.line_8304);

		line_8301.setOnClickListener(this);
		line_8302.setOnClickListener(this);
		line_8303.setOnClickListener(this);
		line_8304.setOnClickListener(this);

		line_8401 = (LinearLayout) view.findViewById(R.id.line_8401);
		line_8402 = (LinearLayout) view.findViewById(R.id.line_8402);
		line_8403 = (LinearLayout) view.findViewById(R.id.line_8403);
		line_8404 = (LinearLayout) view.findViewById(R.id.line_8404);

		line_8401.setOnClickListener(this);
		line_8402.setOnClickListener(this);
		line_8403.setOnClickListener(this);
		line_8404.setOnClickListener(this);

		dbHelper = new MyDataBaseHelper(getActivity(), "info.db", null, 2);
		db = dbHelper.getWritableDatabase();

		get_room_state();
	}

	private void show_Dialog() {
		// TODO Auto-generated method stub
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle("�������");
		builder.setPositiveButton("�ر�", null);
		View view = LayoutInflater.from(getActivity()).inflate(
				R.layout.dialog_base, null, false);
		builder.setView(view);
		final Button btn_yiruzhu, btn_weiruzhu, btn_weidasao;
		final TextView tv_toome_number;
		tv_toome_number = (TextView) view
				.findViewById(R.id.tv_dialog_room_number);
		tv_toome_number.setText("����ţ�" + Room_numebr);
		btn_weidasao = (Button) view.findViewById(R.id.btn_weidasao);
		btn_weiruzhu = (Button) view.findViewById(R.id.btn_weiruzhu);
		btn_yiruzhu = (Button) view.findViewById(R.id.btn_yiruzhu);
		btn_weidasao.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				db.execSQL("insert into room" + Room_numebr
						+ "(roomstate)values(?)", new String[] { "2" });
				get_room_state();
			}
		});
		btn_yiruzhu.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				db.execSQL("insert into room" + Room_numebr
						+ "(roomstate)values(?)", new String[] { "3" });
				get_room_state();
			}
		});
		btn_weiruzhu.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				db.execSQL("insert into room" + Room_numebr
						+ "(roomstate)values(?)", new String[] { "1" });
				get_room_state();
			}
		});
		final TextView tv_temp = (TextView) view.findViewById(R.id.tv_temp);
		final TextView tv_hum = (TextView) view.findViewById(R.id.tv_hum);
		final TextView tv_ill = (TextView) view.findViewById(R.id.tv_ill);
		final TextView tv_press = (TextView) view.findViewById(R.id.tv_press);
		final TextView tv_pm = (TextView) view.findViewById(R.id.tv_pm);
		final TextView tv_per = (TextView) view.findViewById(R.id.tv_per);
		final TextView tv_co = (TextView) view.findViewById(R.id.tv_co);
		final TextView tv_smo = (TextView) view.findViewById(R.id.tv_smo);
		final TextView tv_gas = (TextView) view.findViewById(R.id.tv_gas);

		/**
		 * ���ݲɼ�
		 */
		SocketClient.getInstance().getData(new DataCallback<DeviceBean>() {

			@Override
			public void onResult(final DeviceBean getdata) {
				// TODO Auto-generated method stub
				getActivity().runOnUiThread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						if (!TextUtils.isEmpty(getdata.getAirPressure())) {
							tv_press.setText(getdata.getAirPressure());
						}
						if (!TextUtils.isEmpty(getdata.getCo2())) {
							tv_co.setText(getdata.getCo2());
						}
						if (!TextUtils.isEmpty(getdata.getGas())) {
							tv_gas.setText(getdata.getGas());
						}
						if (!TextUtils.isEmpty(getdata.getHumidity())) {
							tv_hum.setText(getdata.getHumidity());
						}
						if (!TextUtils.isEmpty(getdata.getIllumination())) {
							tv_ill.setText(getdata.getIllumination());
						}
						if (!TextUtils.isEmpty(getdata.getPM25())) {
							tv_pm.setText(getdata.getPM25());
						}
						if (!TextUtils.isEmpty(getdata.getSmoke())) {
							tv_smo.setText(getdata.getSmoke());
						}
						if (!TextUtils.isEmpty(getdata.getTemperature())) {
							tv_temp.setText(getdata.getTemperature());
						}
						if (!TextUtils.isEmpty(getdata.getStateHumanInfrared())) {
							if (getdata.getStateHumanInfrared().equals(
									ConstantUtil.CLOSE)) {
								tv_per.setText("����");
							} else {
								tv_per.setText("����");
							}
						}
					}
				});
			}
		});

		builder.show();
	}

	public void get_room_state() {
		// TODO Auto-generated method stub
		for (int i = 1; i < 5; i++) {
			Cursor cursor = db.rawQuery(
					"select * from room810" + String.valueOf(i), null);
			if (cursor.getCount() != 0) {
				cursor.moveToLast();
				if (i == 1) {
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8101.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8101.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8101.setBackgroundColor(Color.RED);

					}
				}
				if (i == 2) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8102.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8102.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8102.setBackgroundColor(Color.RED);

					}

				}
				if (i == 3) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8103.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8103.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8103.setBackgroundColor(Color.RED);

					}

				}
				if (i == 4) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8104.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8104.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8104.setBackgroundColor(Color.RED);

					}

				}
			}
		}

		for (int i = 1; i < 5; i++) {

			Cursor cursor = db.rawQuery(
					"select * from room840" + String.valueOf(i), null);
			if (cursor.getCount() != 0) {
				cursor.moveToLast();
				if (i == 1) {
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8401.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8401.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8401.setBackgroundColor(Color.RED);

					}
				}
				if (i == 2) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8402.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8402.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8402.setBackgroundColor(Color.RED);

					}

				}
				if (i == 3) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8403.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8403.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8403.setBackgroundColor(Color.RED);

					}

				}
				if (i == 4) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8404.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8404.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8404.setBackgroundColor(Color.RED);

					}

				}
			}
		}

		for (int i = 1; i < 5; i++) {

			Cursor cursor = db.rawQuery(
					"select * from room830" + String.valueOf(i), null);
			if (cursor.getCount() != 0) {
				cursor.moveToLast();
				if (i == 1) {
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8301.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8301.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8301.setBackgroundColor(Color.RED);

					}
				}
				if (i == 2) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8302.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8302.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8302.setBackgroundColor(Color.RED);

					}

				}
				if (i == 3) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8303.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8303.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8303.setBackgroundColor(Color.RED);

					}

				}
				if (i == 4) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8304.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8304.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8304.setBackgroundColor(Color.RED);

					}

				}
			}
		}

		for (int i = 1; i < 5; i++) {

			Cursor cursor = db.rawQuery(
					"select * from room820" + String.valueOf(i), null);
			if (cursor.getCount() != 0) {
				cursor.moveToLast();
				if (i == 1) {
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8201.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8201.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8201.setBackgroundColor(Color.RED);

					}
				}
				if (i == 2) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8202.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8202.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8202.setBackgroundColor(Color.RED);

					}

				}
				if (i == 3) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8203.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8203.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8203.setBackgroundColor(Color.RED);

					}

				}
				if (i == 4) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8204.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8204.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8204.setBackgroundColor(Color.RED);

					}

				}
			}
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.line_8101:
			Room_numebr = "8101";
			show_Dialog();
			break;
		case R.id.line_8102:
			Room_numebr = "8102";
			show_Dialog();
			break;
		case R.id.line_8103:
			Room_numebr = "8103";
			show_Dialog();
			break;
		case R.id.line_8104:
			Room_numebr = "8104";
			show_Dialog();
			break;

		case R.id.line_8301:
			Room_numebr = "8301";
			show_Dialog();
			break;
		case R.id.line_8302:
			Room_numebr = "8302";
			show_Dialog();
			break;
		case R.id.line_8303:
			Room_numebr = "8303";
			show_Dialog();
			break;
		case R.id.line_8304:
			Room_numebr = "8304";
			show_Dialog();
			break;

		case R.id.line_8201:
			Room_numebr = "8201";
			show_Dialog();
			break;
		case R.id.line_8202:
			Room_numebr = "8202";
			show_Dialog();
			break;
		case R.id.line_8203:
			Room_numebr = "8203";
			show_Dialog();
			break;
		case R.id.line_8204:
			Room_numebr = "8204";
			show_Dialog();
			break;

		case R.id.line_8401:
			Room_numebr = "8401";
			show_Dialog();
			break;
		case R.id.line_8402:
			Room_numebr = "8402";
			show_Dialog();
			break;
		case R.id.line_8403:
			Room_numebr = "8403";
			show_Dialog();
			break;
		case R.id.line_8404:
			Room_numebr = "8404";
			show_Dialog();
			break;

		default:
			break;
		}
	}
}
