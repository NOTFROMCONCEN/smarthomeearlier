package com.example.shengsaiademo2019.fragment;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.bizideal.smarthome.socket.ConstantUtil;
import com.bizideal.smarthome.socket.DataCallback;
import com.bizideal.smarthome.socket.DeviceBean;
import com.bizideal.smarthome.socket.SocketClient;
import com.example.shengsaiademo2019.R;
import com.example.shengsaiademo2019.activity.RoomLink;
import com.example.shengsaiademo2019.mysql.MyDataBaseHelper;

public class LinkActivity extends Fragment implements OnClickListener {
	MyDataBaseHelper dbHelper;
	SQLiteDatabase db;
	private LinearLayout line_8101;
	private LinearLayout line_8102;
	private LinearLayout line_8103;
	private LinearLayout line_8104;
	private LinearLayout line_8201;
	private LinearLayout line_8202;
	private LinearLayout line_8203;
	private LinearLayout line_8204;
	private LinearLayout line_8301;
	private LinearLayout line_8302;
	private LinearLayout line_8303;
	private LinearLayout line_8304;
	private LinearLayout line_8401;
	private LinearLayout line_8402;
	private LinearLayout line_8403;
	private LinearLayout line_8404;
	public static String Room_numebr = "";
	public static float temp, hum, ill, press, pm, co, smo, gas, per;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.activity_base_index, container,
				false);
		initView(view);
		/**
		 * ���ݲɼ�
		 */
		SocketClient.getInstance().getData(new DataCallback<DeviceBean>() {

			@Override
			public void onResult(final DeviceBean getdata) {
				// TODO Auto-generated method stub
				getActivity().runOnUiThread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						if (!TextUtils.isEmpty(getdata.getAirPressure())) {
							press = Float.valueOf(getdata.getAirPressure());
						}
						if (!TextUtils.isEmpty(getdata.getCo2())) {
							co = Float.valueOf(getdata.getCo2());
						}
						if (!TextUtils.isEmpty(getdata.getGas())) {
							gas = Float.valueOf(getdata.getGas());
						}
						if (!TextUtils.isEmpty(getdata.getHumidity())) {
							hum = Float.valueOf(getdata.getHumidity());
						}
						if (!TextUtils.isEmpty(getdata.getIllumination())) {
							ill = Float.valueOf(getdata.getIllumination());
						}
						if (!TextUtils.isEmpty(getdata.getPM25())) {
							pm = Float.valueOf(getdata.getPM25());
						}
						if (!TextUtils.isEmpty(getdata.getSmoke())) {
							smo = Float.valueOf(getdata.getSmoke());
						}
						if (!TextUtils.isEmpty(getdata.getTemperature())) {
							temp = Float.valueOf(getdata.getTemperature());
						}
						if (!TextUtils.isEmpty(getdata.getStateHumanInfrared())) {
							if (getdata.getStateHumanInfrared().equals(
									ConstantUtil.CLOSE)) {
								per = 0;
							} else {
								per = 1;
							}
						}
					}
				});
			}
		});
		return view;
	}

	private void initView(View view) {
		// TODO Auto-generated method stub
		line_8101 = (LinearLayout) view.findViewById(R.id.line_8101);
		line_8102 = (LinearLayout) view.findViewById(R.id.line_8102);
		line_8103 = (LinearLayout) view.findViewById(R.id.line_8103);
		line_8104 = (LinearLayout) view.findViewById(R.id.line_8104);

		line_8101.setOnClickListener(this);
		line_8102.setOnClickListener(this);
		line_8103.setOnClickListener(this);
		line_8104.setOnClickListener(this);

		line_8201 = (LinearLayout) view.findViewById(R.id.line_8201);
		line_8202 = (LinearLayout) view.findViewById(R.id.line_8202);
		line_8203 = (LinearLayout) view.findViewById(R.id.line_8203);
		line_8204 = (LinearLayout) view.findViewById(R.id.line_8204);

		line_8201.setOnClickListener(this);
		line_8202.setOnClickListener(this);
		line_8203.setOnClickListener(this);
		line_8204.setOnClickListener(this);

		line_8301 = (LinearLayout) view.findViewById(R.id.line_8301);
		line_8302 = (LinearLayout) view.findViewById(R.id.line_8302);
		line_8303 = (LinearLayout) view.findViewById(R.id.line_8303);
		line_8304 = (LinearLayout) view.findViewById(R.id.line_8304);

		line_8301.setOnClickListener(this);
		line_8302.setOnClickListener(this);
		line_8303.setOnClickListener(this);
		line_8304.setOnClickListener(this);

		line_8401 = (LinearLayout) view.findViewById(R.id.line_8401);
		line_8402 = (LinearLayout) view.findViewById(R.id.line_8402);
		line_8403 = (LinearLayout) view.findViewById(R.id.line_8403);
		line_8404 = (LinearLayout) view.findViewById(R.id.line_8404);

		line_8401.setOnClickListener(this);
		line_8402.setOnClickListener(this);
		line_8403.setOnClickListener(this);
		line_8404.setOnClickListener(this);

		dbHelper = new MyDataBaseHelper(getActivity(), "info.db", null, 2);
		db = dbHelper.getWritableDatabase();

		get_room_state();
	}

	private void get_room_state() {
		// TODO Auto-generated method stub
		for (int i = 1; i < 5; i++) {
			Cursor cursor = db.rawQuery(
					"select * from room810" + String.valueOf(i), null);
			if (cursor.getCount() != 0) {
				cursor.moveToLast();
				if (i == 1) {
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8101.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8101.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8101.setBackgroundColor(Color.RED);

					}
				}
				if (i == 2) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8102.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8102.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8102.setBackgroundColor(Color.RED);

					}

				}
				if (i == 3) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8103.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8103.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8103.setBackgroundColor(Color.RED);

					}

				}
				if (i == 4) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8104.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8104.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8104.setBackgroundColor(Color.RED);

					}

				}
			}
		}

		for (int i = 1; i < 5; i++) {

			Cursor cursor = db.rawQuery(
					"select * from room840" + String.valueOf(i), null);
			if (cursor.getCount() != 0) {
				cursor.moveToLast();
				if (i == 1) {
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8401.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8401.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8401.setBackgroundColor(Color.RED);

					}
				}
				if (i == 2) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8402.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8402.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8402.setBackgroundColor(Color.RED);

					}

				}
				if (i == 3) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8403.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8403.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8403.setBackgroundColor(Color.RED);

					}

				}
				if (i == 4) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8404.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8404.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8404.setBackgroundColor(Color.RED);

					}

				}
			}
		}

		for (int i = 1; i < 5; i++) {

			Cursor cursor = db.rawQuery(
					"select * from room830" + String.valueOf(i), null);
			if (cursor.getCount() != 0) {
				cursor.moveToLast();
				if (i == 1) {
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8301.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8301.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8301.setBackgroundColor(Color.RED);

					}
				}
				if (i == 2) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8302.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8302.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8302.setBackgroundColor(Color.RED);

					}

				}
				if (i == 3) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8303.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8303.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8303.setBackgroundColor(Color.RED);

					}

				}
				if (i == 4) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8304.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8304.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8304.setBackgroundColor(Color.RED);

					}

				}
			}
		}

		for (int i = 1; i < 5; i++) {

			Cursor cursor = db.rawQuery(
					"select * from room820" + String.valueOf(i), null);
			if (cursor.getCount() != 0) {
				cursor.moveToLast();
				if (i == 1) {
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8201.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8201.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8201.setBackgroundColor(Color.RED);

					}
				}
				if (i == 2) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8202.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8202.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8202.setBackgroundColor(Color.RED);

					}

				}
				if (i == 3) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8203.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8203.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8203.setBackgroundColor(Color.RED);

					}

				}
				if (i == 4) {

					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("1")) {
						line_8204.setBackgroundColor(Color.GREEN);
					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("2")) {
						line_8204.setBackgroundColor(Color.GRAY);

					}
					if (cursor.getString(cursor.getColumnIndex("roomstate"))
							.toString().equals("3")) {
						line_8204.setBackgroundColor(Color.RED);

					}

				}
			}
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.line_8101:
			Room_numebr = "8101";
			startActivity(new Intent(getActivity(), RoomLink.class));
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8102:
			Room_numebr = "8102";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8103:
			Room_numebr = "8103";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8104:
			Room_numebr = "8104";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;

		case R.id.line_8301:
			Room_numebr = "8301";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8302:
			Room_numebr = "8302";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8303:
			Room_numebr = "8303";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8304:
			Room_numebr = "8304";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;

		case R.id.line_8201:
			Room_numebr = "8201";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8202:
			Room_numebr = "8202";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8203:
			Room_numebr = "8203";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8204:
			Room_numebr = "8204";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;

		case R.id.line_8401:
			Room_numebr = "8401";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8402:
			Room_numebr = "8402";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8403:
			Room_numebr = "8403";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;
		case R.id.line_8404:
			Room_numebr = "8404";
			startActivity(new Intent(getActivity(), RoomLink.class));
			break;

		default:
			break;
		}
	}
}
