package com.example.shengsaiademo2019;

import com.example.shengsaiademo2019.fragment.BarActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * @author Administrator
 * @year 2019
 * @Todo TODO ���ؽ���
 * @package_name com.example.shengsaiademo2019
 * @project_name 2019ShengSaiADemo
 * @file_name LoadingActivity.java
 */
public class LoadingActivity extends Activity {
	private ProgressBar pg_1;
	private TextView tv_number_1;
	int number = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_loading);
		pg_1 = (ProgressBar) findViewById(R.id.progressBar1);
		tv_number_1 = (TextView) findViewById(R.id.tv_loading_number);
		handler.post(timeRunnable);
	}

	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			pg_1.setProgress(msg.what);
			tv_number_1.setText(String.valueOf(msg.what) + "%");
			if (msg.what == 100) {
				startActivity(new Intent(getApplicationContext(),
						BarActivity.class));
				finish();
			}
			handler.postDelayed(timeRunnable, 1);
		}
	};
	Runnable timeRunnable = new Runnable() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			number++;
			Message msg = handler.obtainMessage();
			msg.what = number;
			if (msg.what > 100) {
				handler.removeCallbacks(timeRunnable);
			} else {
				handler.sendMessage(msg);
			}
		}
	};
}
