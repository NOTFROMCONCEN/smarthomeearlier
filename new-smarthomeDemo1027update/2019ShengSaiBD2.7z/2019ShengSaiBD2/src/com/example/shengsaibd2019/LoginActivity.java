package com.example.shengsaibd2019;

import java.text.SimpleDateFormat;
import java.util.TimeZone;

import com.example.shengsaibd2019.toast.DiyToats;
import com.example.shengsaibd22019.textchanger.TextChanger;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends Activity {
	private Button btn_login;
	private EditText et_user, et_pass, et_port, et_ip;
	private String user, pass, port, ip;
	private TextView tv_tips, tv_time;
	private int number = 0;
	SharedPreferences sharedPreferences;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		initView();// ��
		// �������
		handler.post(timeRunnable);
		// ��¼
		sharedPreferences = getSharedPreferences("rember", MODE_WORLD_WRITEABLE);
		if (sharedPreferences != null) {
			if (sharedPreferences.getBoolean("rember", false) == true) {
				et_user.setText(sharedPreferences.getString("user", null));
				et_port.setText(sharedPreferences.getString("port", null));
				et_ip.setText(sharedPreferences.getString("ip", null));
				et_pass.setText(sharedPreferences.getString("pass", null));
			} else {
				et_ip.setText("12.1.6.2");
				et_pass.setText("123456");
				et_port.setText("6006");
				et_user.setText("bizideal001");
			}
		}
		// ��¼
		btn_login.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				user = et_user.getText().toString();
				pass = et_pass.getText().toString();
				port = et_port.getText().toString();
				ip = et_ip.getText().toString();
				if (user.isEmpty()) {
					DiyToats.showToast(getApplicationContext(), "�������û���");
				} else if (port.isEmpty()) {
					DiyToats.showToast(getApplicationContext(), "������˿�");
				} else if (ip.isEmpty()) {
					DiyToats.showToast(getApplicationContext(), "������IP��ַ");
				} else if (pass.isEmpty()) {
					DiyToats.showToast(getApplicationContext(), "����������");
				} else {
					if (user.equals("bizideal001") && pass.equals("123456")) {
						if (ip.equals("12.1.6.2")) {
							// ��½�ɹ�����ת
							startActivity(new Intent(LoginActivity.this,
									UnLockActivity.class));
							finish();
							// ��ס����
							sharedPreferences.edit().putString("user", user)
									.putBoolean("rember", true)
									.putString("pass", pass)
									.putString("port", port)
									.putString("ip", ip).commit();
						} else {
							DiyToats.showToast(getApplicationContext(),
									"IP�������");
						}
					} else {
						new AlertDialog.Builder(LoginActivity.this)
								.setTitle("��¼ʧ��").setMessage("������û�������")
								.setPositiveButton("Ok", null).show();
					}
				}
			}
		});
		// ת���ַ�
		et_pass.setTransformationMethod(new TextChanger());
	}

	/**
	 * ����ʱ�䡢��˸
	 */
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			// SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
			// "yyyy��MM��dd�� HH:mm:ss");
			// simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
			// tv_time.setText(simpleDateFormat.format(new java.util.Date()));
			SimpleDateFormat sDateFormat = new SimpleDateFormat(
					"yyyy-MM-dd    hh:mm:ss");
			tv_time.setText(sDateFormat.format(new java.util.Date()));
			if (msg.what % 2 == 0) {
				tv_tips.setVisibility(View.INVISIBLE);
			} else {
				tv_tips.setVisibility(View.VISIBLE);
			}
			handler.postDelayed(timeRunnable, 500);
		}
	};
	Runnable timeRunnable = new Runnable() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			number++;
			Message msg = handler.obtainMessage();
			msg.what = number;
			handler.sendMessage(msg);
		}
	};

	private void initView() {
		// TODO Auto-generated method stub
		btn_login = (Button) findViewById(R.id.btn_login);
		et_ip = (EditText) findViewById(R.id.et_ip);
		et_pass = (EditText) findViewById(R.id.et_pass);
		et_port = (EditText) findViewById(R.id.et_port);
		et_user = (EditText) findViewById(R.id.et_user);
		tv_time = (TextView) findViewById(R.id.tv_login_time);
		tv_tips = (TextView) findViewById(R.id.tv_login_tips);
	}
}
